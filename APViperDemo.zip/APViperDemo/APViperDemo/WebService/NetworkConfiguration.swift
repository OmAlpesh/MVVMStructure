//
//  NetworkConfiguration.swift
//  Ooler
//
//  Created by dinesh on 08/05/18.
//  Copyright © 2018 Skookum, Inc. All rights reserved.
//

import UIKit
///
class NetworkConfiguration: NSObject {
    
    // MARK: - Variables
    
    /// Time Interval in second for request time out
    static let timeoutIntervalForRequest = 30.0
    /// Time Interval in second for resource time out
    static let timeoutIntervalForResource = 30.0
  
    static var baseURL: String = "https://kryo-ota.herokuapp.com/"
  
  
  
}
