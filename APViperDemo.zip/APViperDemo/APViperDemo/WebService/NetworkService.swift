//
//  NetworkService.swift
//  Ooler
//
//  Created by dinesh on 07/05/18.
//  Copyright © 2018 Skookum, Inc. All rights reserved.
//

import UIKit
import Alamofire
import Reachability
import CocoaLumberjack

///
class NetworkService {
    
    ///
    var reachability: Reachability?
    ///
    var isReachable: Bool = false
  
    // MARK: - Life Cycle Methods

    ///
    init() {

        //Reachability
        do {
            reachability = Reachability.init()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(self.reachabilityChanged(_:)), name: Notification.Name.reachabilityChanged, object: reachability)
        do {
            try reachability?.startNotifier()
        } catch {
            print("cant access")
        }
    }

    ///
    @objc func reachabilityChanged(_ notification: Notification) {
    
        guard let reachability = notification.object as? Reachability, reachability.connection != .none else {
            DDLogError("Invalid Reachability notification type or connection is none.")
            isReachable = false
            return
        }
        isReachable = true
        DDLogVerbose("Reachable via \(reachability.connection)")
    }

    // MARK: - Alamofire Configuration
    
    ///
    func setAlamofireDefaultConfiguration() {
        
        Alamofire.SessionManager.default.session.configuration.timeoutIntervalForRequest = NetworkConfiguration.timeoutIntervalForRequest
        Alamofire.SessionManager.default.session.configuration.timeoutIntervalForResource = NetworkConfiguration.timeoutIntervalForResource
    }
    
    // MARK: - Request Method
    
    /// Custom API Calling methods. We can call any rest API With this common API calling method.
    ///
    /// - Parameters:
    ///   - path: API path
    ///   - ver: firmware version
    ///   - httpMethod: http Method.
    ///   - queue: queue object.
    ///   - success: success block.
    ///   - failure: failure block.
    func requestFor(parameter: Parameters?, headerParameter: HTTPHeaders?, serverUrl: String, httpMethod: HTTPMethod, queue: DispatchQueue? = nil, success:@escaping (_ response: [String: Any]) -> Void, failure:@escaping ( _ error: Error?) -> Void) {
        
        setAlamofireDefaultConfiguration()
      
        // Set header
        let headerParam = headerParameter == nil ? ["Accept": "application/json"] : headerParameter
        
        Alamofire.request(serverUrl, method: httpMethod, parameters: parameter, encoding: JSONEncoding.default, headers: headerParam).responseJSON(queue: queue) { response in
            if let headers = response.response?.allHeaderFields as? [String: String] {
                if let header = headers["x-access-token"] {
                    print(header)
                }
            }
            switch response.result {
            case .success:
                if let responseDict = response.result.value as? [String: Any] {
                    success(responseDict)
                } else {
                    failure(response.result.error)
                }
            case .failure:
                failure(response.result.error)
            }
        }
    }
    
    /// Download files from server
    ///
    /// - Parameters:
    ///   - fileName: name of file to be downloaded
    ///   - fileExtension: extension of the file
    ///   - apiPath: api url
    ///   - serverUrl: server url
    ///   - headerParameters: header parameter (optional)
    ///   - parameters: parameters (optional)
    ///   - completionHandler: returns handler
    func downloadFilesFromServer(fileName: String, fileExtension: String, apiPath: String, serverUrl: String, headerParameters: HTTPHeaders?, parameters: Parameters?, completionHandler: @escaping (_ progress: Double, _ response: DefaultDownloadResponse?) -> Void) {
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            var documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            documentsURL.appendPathComponent("\(fileName + fileExtension)")
            return (documentsURL, [.removePreviousFile])
        }
        let completeURL = serverUrl + apiPath
        Alamofire.download(
            completeURL,
            method: .post,
            parameters: parameters,
            encoding: JSONEncoding.default,
            headers: headerParameters,
            to: destination).downloadProgress(closure: { (progress) in
                //progress closure
                completionHandler(progress.fractionCompleted, nil)
                print(progress.totalUnitCount)
            }).response(completionHandler: { (defaultDownloadResponse) in
                //response closure
                // 1.0 indicates file downloaded 100%
                completionHandler(1.0, defaultDownloadResponse)
                print(defaultDownloadResponse)
            })
    }
}
