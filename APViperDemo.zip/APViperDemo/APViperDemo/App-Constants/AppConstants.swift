//
//  AppConstants.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation


let PROGRESS_INDICATOR_VIEW_TAG:Int = 10

//let API_NOTICE_LIST:String = "https://api.myjson.com/bins/1bsqcn/"
//let API_MOVIE_LIST:String = "https://api.myjson.com/bins/1h87n6"


let API_SERVERPATH: String = "https://dev.credencys.com/canceris"

let accessToken: String = "/api/get_nonce/?controller=user&method=generate_auth_cookie&insecure=cool"

let cookie: String = "/api/user/generate_auth_cookie/?"

let userAuthService: String = "\(API_SERVERPATH)\(cookie)"

