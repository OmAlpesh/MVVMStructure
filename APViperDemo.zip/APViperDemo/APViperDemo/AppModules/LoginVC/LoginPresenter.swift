//
//  LoginPresenter.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import UIKit

class LoginPresenter: ViewToPresenterLoginProtocol {
   
    var view: PresenterToViewLoginProtocol?
    var interactor: PresenterToInteractorLoginProtocol?
    var router: PresenterToRouterLoginProtocol?
    
    func getNonceServiceMethod() {
        interactor?.nonceServiceCall()
    }
    
    func getAuthCookieMethod(vParam: String){
        interactor?.authCookieServiceCall(preParam: vParam)
    }
    
    func validateAuthCookieMethod() {
        
    }
    
    func getUserProfileMethod() {
        
    }
    
    
    func showProfileViewController(navigationController: UINavigationController, auth: AuthCookieModel) {
        router?.pushToProfileScreen(navigationCotroller: navigationController, auth: auth )
    }
}

extension LoginPresenter: InteractorToPresenterLoginProtocol {

    func nonceServiceSuccess(loginResponce: NonceModel) {
        view?.showNonceResponce(loginResponce: loginResponce)
    }
    
    func nonceServiceFailed() {
        view?.showNonceError()
    }
    
    func authCookieServiceSuccess(authResponce: AuthCookieModel) {
        view?.showAuthCookieResponce(authResponce: authResponce)
    }
    
    func authcookieServiceFailed() {
        view?.showAuthCookieError()
    }
    
}
