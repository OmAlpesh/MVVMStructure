//
//  LoginModel.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import ObjectMapper

//private let ID = "id"
//private let TITLE = "title"
//private let BRIEF = "brief"
//private let FILESOURCE = "filesource"
//
//class LoginModel: Mappable{
//
//    internal var id:String?
//    internal var title:String?
//    internal var brief:String?
//    internal var filesource:String?
//
//    required init?(map:Map) {
//        mapping(map: map)
//    }
//
//    func mapping(map:Map){
//        id <- map[ID]
//        title <- map[TITLE]
//        brief <- map[BRIEF]
//        filesource <- map[FILESOURCE]
//    }


class NonceModel: Mappable{
    
     var controller:String?
     var method:String?
     var nonce:String?
     var status:String?
    
    required init?(map:Map) {
        mapping(map: map)
    }
    
    func mapping(map:Map){
        controller <- map["controller"]
        method <- map["method"]
        nonce <- map["nonce"]
        status <- map["status"]
    }
}


class AuthCookieModel: Mappable{
    
     var cookie:String?
     var cookie_name:String?
     var user:User?
     var status:String?
    
    required init?(map:Map) {
        mapping(map: map)
    }
    
    func mapping(map:Map){
        cookie <- map["cookie"]
        cookie_name <- map["cookie_name"]
        user <- map["user"]
        status <- map["status"]
    }
}

class User: Mappable {
     var avatar:String?
     var description:String?
     var displayname:String?
     var email:String?
     var firstname:String?
     var id:Int?
     var lastname:String?
     var nicename:String?
     var registered:String?
     var url:String?
     var username:String?
    var capabilities: Capabilities?
    required init?(map: Map) {
        mapping(map: map)
    }

    func mapping(map:Map){
        avatar <- map["avatar"]
        description <- map["description"]
        displayname <- map["displayname"]
        email <- map["email"]
        firstname <- map["firstname"]
        id <- map["id"]
        lastname <- map["lastname"]
        nicename <- map["nicename"]
        registered <- map["registered"]
        url <- map["url"]
        username <- map["username"]
        capabilities <- map["capabilities"]
    }
}


class Capabilities: Mappable {
    //    capabilities =         {
    //    subscriber = 1;
    //    };
    var subscriber: Int?
   
    required init?(map: Map) {
        mapping(map: map)
    }
    
    func mapping(map:Map){
        subscriber <- map["subscriber"]
    }
}
