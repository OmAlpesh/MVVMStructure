//
//  LoginRouter.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import UIKit

class LoginRouter: PresenterToRouterLoginProtocol {
    
//    static var mainStoryboard: UIStoryboard {
//        return UIStoryboard(name: "Main", bundle: Bundle.main)
//    }
    
    static func navigateLoginVC() -> LoginViewController {
        let view = Constant.mainStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        
        let presenter: ViewToPresenterLoginProtocol & InteractorToPresenterLoginProtocol = LoginPresenter()
        let interactor: PresenterToInteractorLoginProtocol = LoginInteractor()
        let router: PresenterToRouterLoginProtocol = LoginRouter()
        
        view?.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        interactor.presenter = presenter
        
        return view!
    }
    
    func pushToProfileScreen(navigationCotroller: UINavigationController, auth: AuthCookieModel) {
        let profileModule = ProfileRouter.createProfileModule()
         profileModule.authModel = auth
         
        navigationCotroller.pushViewController(profileModule, animated: true)
    }
   
}
