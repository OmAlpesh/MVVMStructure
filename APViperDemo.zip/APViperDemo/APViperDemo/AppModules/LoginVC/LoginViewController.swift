//
//  LoginViewController.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    var presenter: ViewToPresenterLoginProtocol?
    var nonceModel: NonceModel?
    var authModel: AuthCookieModel?
    
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showProgressIndicator(view: self.view)
        hideProgressIndicator(view: self.view)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginAction(_sender: AnyObject){
        presenter?.getNonceServiceMethod()
    }
}

extension LoginViewController: PresenterToViewLoginProtocol {
    
    func showNonceResponce(loginResponce: NonceModel) {
        print(loginResponce);
        nonceModel = loginResponce
        guard let status: String = nonceModel?.status, let userName: String = txtUsername?.text, let password: String = txtPassword?.text else {
            return
        }
        
        print(status)
        
        if status == "ok" {
        
            if let nonceStr = nonceModel?.nonce {
            // let dict = ["nonce": nonceStr, "username": userName, "password": password, "insecure": "cool"]
               // print(dict)
                let parameterString = "nonce=\(nonceStr)&username=\(userName)&password=\(password)&insecure=cool"
              //  print(parameterString)
                presenter?.getAuthCookieMethod(vParam: parameterString)
            }
        }
    }
    
    func showNonceError() {
        
    }
    
    func showAuthCookieResponce(authResponce: AuthCookieModel) {
        authModel = authResponce
        print(authModel?.user?.id ?? "")
        presenter?.showProfileViewController(navigationController: navigationController!, auth: authModel!)
    }
    
    func showAuthCookieError() {
        
    }
    
}
