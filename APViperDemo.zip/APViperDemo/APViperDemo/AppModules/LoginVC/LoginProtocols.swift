//
//  LoginProtocols.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import UIKit

class NavigationRouter
{
    static let shared = NavigationRouter()
    
   let navigationObj = UINavigationController()
}

protocol ViewToPresenterLoginProtocol: class {
    
    var view: PresenterToViewLoginProtocol? {get set}
    var interactor: PresenterToInteractorLoginProtocol? {get set}
    var router: PresenterToRouterLoginProtocol? { get set}
    
    func getNonceServiceMethod()
   // func getAuthCookieMethod(vParam: Dictionary<String, String>)
    func getAuthCookieMethod(vParam: String)
    
    func showProfileViewController(navigationController: UINavigationController, auth: AuthCookieModel)
}

protocol PresenterToViewLoginProtocol: class{
    func showNonceResponce(loginResponce:NonceModel)
    func showNonceError()
    
    func showAuthCookieResponce(authResponce: AuthCookieModel)
    func showAuthCookieError()
    
}

protocol PresenterToInteractorLoginProtocol: class{
    var presenter: InteractorToPresenterLoginProtocol? {get set}
   
    func nonceServiceCall()
    //func authCookieServiceCall(preParam: Dictionary<String, String>)
    func authCookieServiceCall(preParam: String)
}

protocol InteractorToPresenterLoginProtocol: class{
    func nonceServiceSuccess(loginResponce:NonceModel)
    func nonceServiceFailed()
    
    func authCookieServiceSuccess(authResponce: AuthCookieModel)
    func authcookieServiceFailed()
    
}

protocol PresenterToRouterLoginProtocol: class{
    static func navigateLoginVC() -> LoginViewController
    func pushToProfileScreen(navigationCotroller: UINavigationController, auth: AuthCookieModel)
}


