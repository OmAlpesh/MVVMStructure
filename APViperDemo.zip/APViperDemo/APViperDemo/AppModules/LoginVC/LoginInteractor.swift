//
//  LoginInteractor.swift
//  APViperDemo
//
//  Created by alpesh on 03/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import Alamofire
import ObjectMapper

class LoginInteractor: PresenterToInteractorLoginProtocol {
    
    var presenter: InteractorToPresenterLoginProtocol?
    
    let network = NetworkService()
    
    func nonceServiceCall() {

        network.requestFor(parameter: nil, headerParameter: nil, serverUrl: API_SERVERPATH+accessToken, httpMethod: .get, success: {  (response) in
          
            print(response)
         
                // let arrayResponse = json["notice_list"] as! NSArray
                // let arrayObject = Mapper<LoginModel>().mapArray(JSONArray: json as! [[String : Any]]);
                let dictObject = Mapper<NonceModel>().map(JSON: response)
                print(dictObject ?? "")
                
                self.presenter?.nonceServiceSuccess(loginResponce: dictObject!)
            
            }, failure: {  (error) in
                print(error ?? "")
                 self.presenter?.nonceServiceFailed()
        })
    }
    
    func authCookieServiceCall(preParam: String) {
        
        let url = "\(userAuthService)\(preParam)"
        network.requestFor(parameter: nil, headerParameter: nil, serverUrl: url, httpMethod: .get, success: { (responce) in
            print(responce)
            let dictObject = Mapper<AuthCookieModel>().map(JSON: responce);
            print(dictObject ?? "")
            self.presenter?.authCookieServiceSuccess(authResponce: dictObject!)
            
        }) { (error) in
            print(error ?? "")
            self.presenter?.authcookieServiceFailed()
        }
        
       /* let url = "\(userAuthService)\(preParam)"

        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseJSON {
            response in
            switch response.result {
            case .success:
                print(response)
                if response.response?.statusCode == 200 {
                    if let json = response.result.value as AnyObject?{
                        print(json)
                        let dictObject = Mapper<AuthCookieModel>().map(JSON: json as! [String : Any]);
                        print(dictObject ?? "")
                        self.presenter?.authCookieServiceSuccess(authResponce: dictObject!)
                    }
                }
                break
            case .failure(let error):
                
                print(error)
                self.presenter?.authcookieServiceFailed()
            }
        }
 */
    }
    
}
