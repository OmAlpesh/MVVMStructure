//
//  AddGatewayRouter.swift
//  APViperDemo
//
//  Created by alpesh on 16/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import UIKit


class AddGatewatRouter: GatewayPresenterToRouterProtocol {
    
   static func createGatewayModule() -> AddGatewayViewController {
        
        let view = Constant.mainStoryboard.instantiateViewController(withIdentifier: "AddGatewayViewController") as? AddGatewayViewController
        
        let presenter: GatewayViewToPresenterProtocol &
         GatewayInteractorToPresenterProtocol = AddGatewayPresenter()
        let interactor: GatewayPresenterToInteractorProtocol = AddGatewayInteractor()
        let router: GatewayPresenterToRouterProtocol = AddGatewatRouter()
        
        view?.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        
        return view!
    }

}
