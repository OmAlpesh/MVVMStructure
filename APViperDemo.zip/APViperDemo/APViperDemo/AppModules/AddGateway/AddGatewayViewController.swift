//
//  AddGatewayViewController.swift
//  APViperDemo
//
//  Created by alpesh on 16/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class AddGatewayViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var florTxt: UITextField!
    @IBOutlet weak var locationTxt: UITextField!
    @IBOutlet weak var descriptionTxt: UITextField!
    @IBOutlet weak var nextBtn: UIButton!
    
    // MARK: - Variables
    var presenter: GatewayViewToPresenterProtocol?
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        print(NavigationRouter.shared.navigationObj)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupUI(){
        nextBtn.layer.cornerRadius = nextBtn.frame.size.height/2.5
    }
    

    // MARK: - User Actions
    @IBAction func nextTapped(_ sender: Any) {
        
    }

}

extension AddGatewayViewController: GatewayPresenterToViewProtocol {
    
}
