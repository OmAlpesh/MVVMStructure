//
//  AddGatewayInteractor.swift
//  APViperDemo
//
//  Created by alpesh on 16/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation

class AddGatewayInteractor: GatewayPresenterToInteractorProtocol {
    
}
