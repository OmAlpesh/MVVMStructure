//
//  AddGatewayProtocol.swift
//  APViperDemo
//
//  Created by alpesh on 16/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import UIKit

protocol GatewayViewToPresenterProtocol: class {
    
    var view: GatewayPresenterToViewProtocol? { get set}
    var interactor: GatewayPresenterToInteractorProtocol? { get set}
    var router: GatewayPresenterToRouterProtocol? { set get}
    
    
}

protocol GatewayPresenterToViewProtocol: class {
    
}

protocol GatewayPresenterToInteractorProtocol: class {
    
}

protocol GatewayInteractorToPresenterProtocol: class {
    
}

protocol GatewayPresenterToRouterProtocol: class {
    static func createGatewayModule() -> AddGatewayViewController
    
}
