//
//  GatewayContinueViewController.swift
//  APViperDemo
//
//  Created by alpesh on 16/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class GatewayContinueViewController: UIViewController {

    // MARK: - Outlets
     @IBOutlet weak var continueBtn: UIButton!
     @IBOutlet weak var view4: UIView!
     @IBOutlet weak var view2: UIView!
     @IBOutlet weak var view3: UIView!
    
    // MARK: - Variables
    
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()

       setupUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI(){
        continueBtn.layer.cornerRadius = continueBtn.frame.size.height/2.5
        view4.layer.cornerRadius = 3
        view2.layer.cornerRadius = 3
        view3.layer.cornerRadius = 3
    }

    // MARK: - User Actions
    @IBAction func continueTapped(_ sender: Any) {
        
    }

}
