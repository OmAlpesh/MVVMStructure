//
//  ProfileInteractor.swift
//  APViperDemo
//
//  Created by alpesh on 15/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation

class ProfileInteractor: ProfilePresenterToInteractorProtocol {
    
}
