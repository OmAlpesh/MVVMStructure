//
//  ProfileRouter.swift
//  APViperDemo
//
//  Created by alpesh on 15/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation

class ProfileRouter: ProfilePresenterToRouterProtocol {
 
    static func createProfileModule() -> ProfileViewController {
      
        let view = Constant.mainStoryboard.instantiateViewController(withIdentifier: "ProfileViewController") as? ProfileViewController
      
        let presenter: ProfieViewToPresenterProtocol & ProfileInteractorToPresenterProtocol = ProfilePresenter()
        let interactor: ProfilePresenterToInteractorProtocol = ProfileInteractor()
        let router: ProfilePresenterToRouterProtocol = ProfileRouter()
        
        view?.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        
        return view!
    }
    
    
    func pushToGatewayScreen(navigationCotroller: NavigationRouter) {
        let addGateway = AddGatewatRouter.createGatewayModule()
    navigationCotroller.navigationObj.pushViewController(addGateway, animated: true)
    }

}
