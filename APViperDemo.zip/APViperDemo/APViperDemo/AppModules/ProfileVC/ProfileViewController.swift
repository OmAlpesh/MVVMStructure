//
//  ProfileViewController.swift
//  APViperDemo
//
//  Created by alpesh on 15/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtEmailID: UITextField!
    @IBOutlet weak var txtCapabilities: UITextField!
    @IBOutlet weak var txtCookie: UITextField!
    @IBOutlet weak var txtDisplayName: UITextField!
    
    var presenter: ProfieViewToPresenterProtocol?
    var authModel: AuthCookieModel?
   

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       setupUI()
    }

    func setupUI(){
        txtCookie.text = authModel?.cookie_name
        txtEmailID.text = authModel?.user?.email
        txtUsername.text = authModel?.user?.username
        txtFirstName.text = authModel?.user?.firstname
        txtDisplayName.text = authModel?.user?.displayname
    
        txtCapabilities.text = "\(String(describing: authModel?.user?.capabilities?.subscriber))"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func editTapped(_ sender: Any) {
        presenter?.showGatewayViewController(navigationController: NavigationRouter.shared)
    }
    
}

extension ProfileViewController: ProfilePresenterToViewProtocol {
    
}

