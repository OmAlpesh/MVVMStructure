//
//  ProfilePresenter.swift
//  APViperDemo
//
//  Created by alpesh on 15/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation

class ProfilePresenter: ProfieViewToPresenterProtocol {
    
    var view: ProfilePresenterToViewProtocol?
    var interactor: ProfilePresenterToInteractorProtocol?
    var router: ProfilePresenterToRouterProtocol?
    

    func showGatewayViewController(navigationController: NavigationRouter) {
        
        router?.pushToGatewayScreen(navigationCotroller: NavigationRouter.shared)
    }
}

extension ProfilePresenter: ProfileInteractorToPresenterProtocol {
    
}
