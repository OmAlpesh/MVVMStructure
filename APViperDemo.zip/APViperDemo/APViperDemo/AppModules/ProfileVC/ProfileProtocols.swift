//
//  ProfileProtocols.swift
//  APViperDemo
//
//  Created by alpesh on 15/10/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import UIKit

protocol ProfieViewToPresenterProtocol: class {
    var view: ProfilePresenterToViewProtocol? {get set}
    var interactor: ProfilePresenterToInteractorProtocol? { get set}
    var router: ProfilePresenterToRouterProtocol? { get set}
  
    func showGatewayViewController(navigationController: NavigationRouter)
}

protocol ProfilePresenterToViewProtocol: class {
    
}

protocol ProfilePresenterToInteractorProtocol: class {
    
}

protocol ProfileInteractorToPresenterProtocol: class {
    
}

protocol ProfilePresenterToRouterProtocol: class {
    static func createProfileModule() -> ProfileViewController

    func pushToGatewayScreen(navigationCotroller: NavigationRouter)
}
