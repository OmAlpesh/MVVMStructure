//
//  RegistrationViewModel.swift
//  MvvmDemo
//
//  Created by alpesh on 05/09/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import Foundation
import SimpleTwoWayBinding

struct RegistrationModel {
    
    let userName: Observable<String> = Observable()
    let emailId: Observable<String> = Observable()
    let passWord: Observable<String> = Observable()
    
    /*
    let isCurrentEmployer: Observable<Bool> = Observable(false)
    let approxSalary: Observable<Float> = Observable()
     
    func getExperienceString() -> String {
        if let yearsOfExperience = yearsOfExperience.value {
            return "\(String(describing: yearsOfExperience)) yrs"
        }
        return "--"
    }
    
    func getSalaryString() -> String {
        if let approxSalary = approxSalary.value {
            let normalizedValue = approxSalary / 1000.0
            return "\(normalizedValue)k"
            
        }
        return "--"
    }
    
    func getPrettyString() -> String {
        return
            "Name: \(String(describing: name.value ?? "--"))\n" +
                "Company: \(String(describing: companyName.value ?? "--"))\n" +
                "Experience: \(getExperienceString())\n" +
                "Current Employer?: \(((isCurrentEmployer.value ?? false) ? "YES" : "NO"))\n" +
                "approx Salary: \(getSalaryString())\n" +
        "Comments: \(String(describing: comments.value ?? "--"))"
    }
    */
}
