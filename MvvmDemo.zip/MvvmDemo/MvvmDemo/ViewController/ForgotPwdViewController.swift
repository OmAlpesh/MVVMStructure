//
//  ForgotPwdViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 30/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit
import BSKeyboardControls

class ForgotPwdViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var txtEmailId: UITextField!
    @IBOutlet weak var btnSend: UIButton!
    
    // MARK: - Variables
   
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        //Navigation bar
        self.navigationController?.isNavigationBarHidden = true
        self.setupUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI(){
        btnSend.layer.cornerRadius = btnSend.frame.size.height/2.5
    }
    // MARK: - User Actions
    @IBAction func sendTapped(_ sender: Any) {
        if let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") {
            CommonMethods.navigateTo(loginVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }

}
