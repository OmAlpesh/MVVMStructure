//
//  LoginViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 30/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit
import BSKeyboardControls

class LoginViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnForgotPassword: UIButton!
    @IBOutlet weak var btnSignIn: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    
    // MARK: - Variables
    var keyboardControls: BSKeyboardControls?
    lazy var fields: [UITextField] = {
        
        return {
            [self.txtUserName, self.txtPassword]
        }
        }()()
    var registerModel: RegistrationModel!
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        //Navigation bar
        self.navigationController?.isNavigationBarHidden = true
        registerModel = RegistrationModel()
        self.setupUI()
    }
    func setupUI(){
        keyboardControls = BSKeyboardControls.init(fields: fields)
        keyboardControls?.delegate = self
        
        btnSignIn.layer.cornerRadius = btnSignIn.frame.size.height/2.5
        btnSignUp.layer.cornerRadius = btnSignUp.frame.size.height/2.5
        
        txtUserName.text = registerModel.userName.value
        txtPassword.text = registerModel.passWord.value
        txtUserName.bind(with: registerModel.userName)
        txtPassword.bind(with: registerModel.passWord)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
//    func userMethod(name: String, mark: Int=123){
//        
//    }
    
    // MARK: - User Actions
    @IBAction func forgotPasswordTapped(_ sender: Any) {
        let forgotPasswordVC = Constant.signUpStoryboard.instantiateViewController(withIdentifier: "ForgotPwdViewController")
        CommonMethods.navigateTo(forgotPasswordVC, inNavigationViewController: self.navigationController!, animated: true)
    }
    
    @IBAction func signInTapped(_ sender: Any) {
        //Resign TextFields
        fields.resignAllTextfields(arrTxtFields: fields)
        
        NotificationCenter.default.post(name: Notification.Name("TabBarRootVoew"), object: nil)
        
        Constant.defaults.set(true, forKey: "isLogin")
    }
    
    @IBAction func signUpTapped(_ sender: Any) {
        if let signupVC = Constant.signUpStoryboard.instantiateViewController(withIdentifier: "SignUpViewController") as? SignUpViewController {
            CommonMethods.navigateTo(signupVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }
}

// MARK: - Textfield Methods
extension LoginViewController: UITextFieldDelegate {
    
    // MARK: UITextfield delegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardControls?.activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       // textField.resignFirstResponder()
        
        if (textField == txtUserName)
        {
            txtUserName.resignFirstResponder()
            txtPassword.becomeFirstResponder()
        }
        
        return true
    }
}
// MARK: - Keyboard Delegate
extension LoginViewController: BSKeyboardControlsDelegate {
    func keyboardControlsDonePressed(_ keyboardControls: BSKeyboardControls) {
        self.view.endEditing(true)
    }
}
