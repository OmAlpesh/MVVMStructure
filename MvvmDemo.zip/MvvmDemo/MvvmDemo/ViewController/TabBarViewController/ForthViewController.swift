//
//  ForthViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 31/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class ForthViewController: UIViewController {

    // MARK: - Outlat's
    @IBOutlet weak var eventSegment: UISegmentedControl!
    @IBOutlet weak var eventTableView: UITableView!
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI() {
        eventTableView.rowHeight = UITableViewAutomaticDimension
        eventTableView.estimatedRowHeight = 40
        eventTableView.register(UINib(nibName: "PractisTableViewCell", bundle: nil), forCellReuseIdentifier: "PractisTableViewCell")
    }
    
    
    // MARK: - Action Method
    
    @IBAction func indexChanged(_ sender: AnyObject) {
        switch eventSegment.selectedSegmentIndex
        {
        case 0:
            print("1")
        case 1:
            print("2")
        default:
            break
        }
    }
    
}

// MARK: - UITableViewDataSource
extension ForthViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PractisTableViewCell", for: indexPath) as? PractisTableViewCell else {
            return UITableViewCell()
        }
        
        cell.titleLabel.text = "GroupName"
        cell.subTitleLabel.text = "ABCD"
        
        return cell
    }
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}
