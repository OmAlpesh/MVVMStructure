//
//  SecondViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 31/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    // MARK: - Outlat's
    @IBOutlet weak var vwPageController: UIView!
    @IBOutlet weak var vwIndicatorWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var vwIndicatorLeadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var recivedButton: UIButton!
    @IBOutlet weak var givenButton: UIButton!
    
    
    // MARK: Variables
    let pageViewController: UIPageViewController = (Constant.tabBarStoryboard.instantiateViewController(withIdentifier: "PageViewController") as? UIPageViewController)!
    var viewControllers: [UIViewController]?
    var selectedPageIndex: Int = 0
    
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

      // setupUI()
        setupPageViewController()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupUI() {
//        practisTableView.rowHeight = UITableViewAutomaticDimension
//        practisTableView.estimatedRowHeight = 40
//        practisTableView.register(UINib(nibName: "PractisTableViewCell", bundle: nil), forCellReuseIdentifier: "PractisTableViewCell")
    }

    private func setupPageViewController() {
        pageViewController.view.backgroundColor = UIColor.clear
        vwPageController.backgroundColor = UIColor.clear
        pageViewController.delegate = self
        pageViewController.dataSource = self
        
        let recivedVC = Constant.tabBarStoryboard.instantiateViewController(withIdentifier: "RecivedViewController") as? RecivedViewController
        
        let givenVC = Constant.tabBarStoryboard.instantiateViewController(withIdentifier: "givenViewController") as? givenViewController
      
        viewControllers = [recivedVC!, givenVC!]
        pageViewController.view.frame = vwPageController.bounds
        self.addChildViewController(pageViewController)
        vwPageController.addSubview(pageViewController.view)
        pageViewController.didMove(toParentViewController: self)
        
        moveToSelectedPageIndex(selectedPageIndex)
        showSelectionIndicatorFor(pageIndex: selectedPageIndex)
    }
    
    open func moveToSelectedPageIndex(_ index: NSInteger) {
        var direction: UIPageViewControllerNavigationDirection = UIPageViewControllerNavigationDirection.forward
        if selectedPageIndex > index {
            direction = UIPageViewControllerNavigationDirection.reverse
        }
        selectedPageIndex = index
        let currentStepController = viewControllers?[selectedPageIndex]
        pageViewController.setViewControllers([currentStepController!], direction:direction, animated: true, completion: nil)
    }
    
    open func showSelectionIndicatorFor(pageIndex: Int) {
        if pageIndex == 0 {
            showSelectionIndicatorFor(button: recivedButton)
        } else if pageIndex == 1 {
            showSelectionIndicatorFor(button: givenButton)
        }
    }
    
    private func showSelectionIndicatorFor(button: UIButton) {
        DispatchQueue.main.async {
            self.vwIndicatorLeadingConstraint.constant = (button.superview?.frame.origin.x)!
            self.vwIndicatorWidthConstraint.constant = (button.superview?.frame.size.width)!
          //  weak var weakSelf = self
            UIView.animate(withDuration: 0.3, animations: {
                button.superview?.superview?.layoutIfNeeded()
            }, completion: { (_: Bool) in
                //Api call for both view
               // weakSelf?.getProductsFromServerFor(searchText: "")
            })
        }
    }
    
    // MARK: - Action Method
    @IBAction func btnTabOptionTapped(_ sender: UIButton) {
        moveToSelectedPageIndex(sender.tag - 101)
        showSelectionIndicatorFor(button: sender)
    }
}


// MARK: UIPageViewControllerDataSource
extension SecondViewController: UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = viewControllers?.index(of: viewController) else {
            return nil
        }
        let previousIndex = viewControllerIndex - 1
        guard previousIndex >= 0 else {
            return nil
        }
        return viewControllers?[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let viewControllerIndex = viewControllers?.index(of: viewController) else {
            return nil
        }
        let nextIndex = viewControllerIndex + 1
        let orderedViewControllersCount = viewControllers?.count
        guard orderedViewControllersCount != nextIndex else {
            return nil
        }
        guard orderedViewControllersCount! > nextIndex else {
            return nil
        }
        return viewControllers?[nextIndex]
    }
}

// MARK: UIPageViewControllerDelegate
extension SecondViewController: UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if finished == true {
            if let pageIndex = (viewControllers?.index(of: (pageViewController.viewControllers?.last)!)) {
                if pageIndex != selectedPageIndex {
                    selectedPageIndex = pageIndex
                showSelectionIndicatorFor(pageIndex:selectedPageIndex)
                }
            }
        }
    }
}
