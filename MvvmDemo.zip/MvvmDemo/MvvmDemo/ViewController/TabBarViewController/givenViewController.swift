//
//  givenViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 12/11/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class givenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
}
