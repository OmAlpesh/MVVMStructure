//
//  TabBarViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 31/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

      // MARK: - Variables
    //var drawerContainer: MMDrawerController?
    
      // MARK: - ViewLifew Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

}
