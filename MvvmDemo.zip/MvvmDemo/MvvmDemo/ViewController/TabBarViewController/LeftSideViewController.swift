//
//  LeftSideViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 31/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class LeftSideViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var sideMenuTableView: UITableView!
    
    
    // MARK: - ViewLife cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        sideMenuTableView.reloadData()
        setupUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI() {
        sideMenuTableView.rowHeight = UITableViewAutomaticDimension
        sideMenuTableView.estimatedRowHeight = 40
        sideMenuTableView.register(UINib(nibName: "SideMenuTableViewCell", bundle: nil), forCellReuseIdentifier: "SideMenuTableViewCell")
        
         profileImg.layer.cornerRadius = profileImg.frame.size.width/2
    }
}

// MARK: - UITableViewDataSource
extension LeftSideViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SideMenuTableViewCell", for: indexPath) as? SideMenuTableViewCell else {
            return UITableViewCell()
        }
        
        cell.titleLbl.text = "Profile"
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         let loginVc = Constant.signUpStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController
        Constant.defaults.set(false, forKey: "isLogin")
        
        // Wrap into Navigation controllers
        let loginNav = UINavigationController(rootViewController:loginVc!)
        
        Constant.appDelegate?.window?.rootViewController = loginNav

    }

    //    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}
