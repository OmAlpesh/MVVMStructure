//
//  ThirdViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 31/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    // MARK: - Outlat's
    @IBOutlet weak var inboxTableView: UITableView!
    @IBOutlet weak var inboxSearchbar: UISearchBar!
    
    //MARK: - variable
    var searchActive : Bool = false
    var data = ["San Francisco","New York","San Jose","Chicago","Los Angeles","Austin","Seattle"]
    var filtered:[String] = []
    
    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI() {
        // inboxSearchbar.showsCancelButton = true
        inboxTableView.rowHeight = UITableViewAutomaticDimension
        inboxTableView.estimatedRowHeight = 40
        inboxTableView.register(UINib(nibName: "InboxTableViewCell", bundle: nil), forCellReuseIdentifier: "InboxTableViewCell")
    }
    
}
// MARK: - UITableViewDataSource
extension ThirdViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(searchActive) {
            return filtered.count
        }
        return data.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "InboxTableViewCell", for: indexPath) as? InboxTableViewCell else {
            return UITableViewCell()
        }
        
        if(searchActive){
            cell.titleLabel.text = filtered[indexPath.row]
        } else {
            cell.titleLabel.text = data[indexPath.row];
        }
        
       // cell.titleLabel.text = "GroupName"
        cell.descLabel.text = "ABCD"
        cell.dayLabel.text = "Yesterday"
        return cell
    }
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}

// MARK: - UITableViewDataSource
extension ThirdViewController: UISearchBarDelegate {
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        searchActive = false;
        inboxTableView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
        inboxTableView.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchActive = false;
        inboxTableView.reloadData()
    }
    

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.count == 0 {
            searchActive = false
            inboxTableView.reloadData()
            return
        }
        
        filtered = data.filter({ (text) -> Bool in
            let tmp: NSString = text as NSString
            let range = tmp.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            return range.location != NSNotFound
        })
//        if(filtered.count == 0){
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
        searchActive = true;
        inboxTableView.reloadData()
    }
}
