//
//  FirstViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 31/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    // MARK: - OutLat's
    @IBOutlet weak var groupTableView: UITableView!
    
    // MARK: - Variable
    
    
    // MARK: - ViewLife Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI() {
        groupTableView.rowHeight = UITableViewAutomaticDimension
        groupTableView.estimatedRowHeight = 40
        groupTableView.register(UINib(nibName: "GroupTableViewCell", bundle: nil), forCellReuseIdentifier: "GroupTableViewCell")
    }
    // MARK: - Action Method
    @IBAction func leftSideButtonTapped(sender: AnyObject) {
        
        Constant.drawerContainer.maximumLeftDrawerWidth = 300
        Constant.drawerContainer.toggle(MMDrawerSide.left, animated: true, completion: nil)
    }
    
    @IBAction func addTapped(sender: AnyObject) {
                
    }
}


// MARK: - UITableViewDataSource
extension FirstViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "GroupTableViewCell", for: indexPath) as? GroupTableViewCell else {
            return UITableViewCell()
        }
        
        cell.titleLabel.text = "GroupName"
        cell.subTitleLabel.text = "ABCD"
       
        return cell
    }
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}
