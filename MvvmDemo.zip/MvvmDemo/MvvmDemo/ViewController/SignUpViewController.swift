//
//  SignUpViewController.swift
//  MvvmDemo
//
//  Created by alpesh on 30/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit
import BSKeyboardControls
import SimpleTwoWayBinding

class SignUpViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtEmailId: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnSignUp: UIButton!
   /* @IBOutlet weak var commentsView: BindableTextView! {
        didSet {
            commentsView.layer.borderColor = UIColor.lightGray.cgColor
            commentsView.layer.cornerRadius = 5.0
            commentsView.layer.borderWidth = 1.0
        }
    }*/
    
    // MARK: - Variables
    var keyboardControls: BSKeyboardControls?
    lazy var fields: [UITextField] = {
        
        return {
            [self.txtUserName,self.txtEmailId, self.txtPassword]
        }
        }()()
    var registerModel: RegistrationModel!
    
    // MARK: - Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        //Navigation bar
        self.navigationController?.isNavigationBarHidden = true
        registerModel = RegistrationModel()
        self.setupUI()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func setupUI(){
        keyboardControls = BSKeyboardControls.init(fields: fields)
        keyboardControls?.delegate = self
        
        btnSignUp.layer.cornerRadius = btnSignUp.frame.size.height/2.5
        setupBindings()
    }
    func setupBindings() {
        txtUserName.bind(with: registerModel.userName)
        txtEmailId.bind(with: registerModel.emailId)
        txtPassword.bind(with: registerModel.passWord)
      /*  selectedSalaryRangeLabel.observe(for: viewModel.approxSalary) {
            [unowned self](_) in
            self.selectedSalaryRangeLabel.text =
                self.viewModel.getSalaryString()
        }*/
    
    }
    // MARK: - User Actions
    @IBAction func signUpTapped(_ sender: Any) {
        //Resign TextFields
        fields.resignAllTextfields(arrTxtFields: fields)
        if let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            loginVC.registerModel = registerModel
            CommonMethods.navigateTo(loginVC, inNavigationViewController: self.navigationController!, animated: true)
        }
    }

}

// MARK: - Textfield Methods
extension SignUpViewController: UITextFieldDelegate {
    
    // MARK: UITextfield delegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        keyboardControls?.activeField = textField
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // textField.resignFirstResponder()
        
        if (textField == txtUserName) {
            txtUserName.resignFirstResponder()
            txtEmailId.becomeFirstResponder()
            } else if (textField == txtEmailId) {
                txtEmailId.resignFirstResponder()
                txtPassword.becomeFirstResponder()
          }
        return true
    }
}
// MARK: - Keyboard Delegate
extension SignUpViewController: BSKeyboardControlsDelegate {
    func keyboardControlsDonePressed(_ keyboardControls: BSKeyboardControls) {
        self.view.endEditing(true)
    }
}
