//
//  CommonExtensions.swift
//  MvvmDemo
//
//  Created by alpesh on 30/08/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

import UIKit

// MARK: - Array + UITextField
extension Array {
    func resignAllTextfields(arrTxtFields: [UITextField]) {
        arrTxtFields.forEach { $0.resignFirstResponder()
        }
    }
    
    func emptyAllTextfields() {
        self.forEach { if let txt = $0 as? UITextField {
            txt.text = ""
            }
        }
    }
}

// MARK: - Date
extension Date {
    func stringFor(format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        let strDate = dateFormatter.string(from: self)
        return strDate
    }
}

// MARK: - UITextField
extension UITextField {
    func requiredFieldIndicatior() {
        guard let placeHolderText = self.placeholder, placeHolderText.characters.last == "*" else {
            return
        }
        let myMutableString = NSMutableAttributedString(
            string: placeHolderText,
            attributes: nil)
        myMutableString.addAttribute(
            kCTForegroundColorAttributeName as NSAttributedStringKey,
            value: UIColor.red,
            range: NSRange(location:placeHolderText.characters.count-1, length:1))
        self.attributedPlaceholder = myMutableString
    }
}

// MARK: - UILabel
extension UILabel {
    func requiredFieldIndicatior() {
        
        self.text?.characters.append("*")
        let myMutableString = NSMutableAttributedString(
            string: self.text!,
            attributes: nil)
        myMutableString.addAttribute(
            kCTForegroundColorAttributeName as NSAttributedStringKey,
            value: UIColor.red,
            range: NSRange(location:(self.text?.characters.count)!-1, length:1))
        self.attributedText = myMutableString
    }
}

@IBDesignable
class DesignableView: UIView {
}

@IBDesignable
class DesignableButton: UIButton {
}

@IBDesignable
class DesignableLabel: UILabel {
}

extension UIView {
    
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    
    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }
    
    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable
    var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
}

extension UIViewController {
    /// common alert controller
    func showAlertView(title: String, message: String, buttonTitile: String) {
        DispatchQueue.main.async { [unowned self] in
            let alert: UIAlertController = UIAlertController(title: title, message: message, preferredStyle: .alert )
            alert.addAction(UIAlertAction(title: buttonTitile, style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
