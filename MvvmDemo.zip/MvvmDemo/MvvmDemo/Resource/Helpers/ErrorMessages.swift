//
//  ErrorMessages.swift
//  jsw
//
//  Created by jignesh on 18/08/17.
//  Copyright © 2017 credencys. All rights reserved.
//

import Foundation

struct ErrorMessages {
    static let unauthorizedError = "Unauthorized."
    static let unknowError = "Something went wrong."
    static let statusCodeError = "Status code not available."
    static let authenticationError = "Authentication token was either missing or invalid."
    static let internalServerError = "Internal server error."
    static let serviceFailError = "Service failed."
    static let emptyDataError = "No data available."
    static let enableAPNsSetting = "It seems like APNs services aren't enabled on your device, Please enable it to use the Push Notification functionality."
}
