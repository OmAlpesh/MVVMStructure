//
//  Enums.swift
//  NorthGate
//
//  Created by Hardik Kothari on 10/03/17.
//  Copyright © 2017 OSS Cube. All rights reserved.
//

import UIKit

enum PaymentType: String {
    case full = "fullpayment"
    case partial = "partialpayment"
}

enum ItemListCategory {
    case all
    case featured
    case new
    case lastOrdered
    case relatedItems
}

enum PaymentMethodType: String {
    case none = "none", card = "worldpaycc", ach = "worldpayach"
}

enum SideMenuItems: Int {
    case orderNow = 0
    case myOrders = 1
    case settings = 2
    case signOut = 3
}

enum AlertType: Int {
    case Login = 1
    case Other = 0
}
