//
//  CommonString.swift
//  jsw
//
//  Created by jignesh on 18/08/17.
//  Copyright © 2017 credencys. All rights reserved.
//

import Foundation

let logoutUser              = "Are you sure you want to logout?"

struct CommonString {
    static let thanks       = "Thanks!"
    static let yes          = "Yes"
    static let noo          = "No"
    static let okay         = "Okay"
    static let comingSoon   = "Coming Soon"
    static let cancel       = "Cancel"
}

struct ConditionalString {
    static let approve                  = "APPROVE"
    static let reject                   = "REJECT"
    static let askAnExpert              = "ASK AN EXPERT"
    static let askClarification         = "ASK CLARIFICATION"
    static let giveExpertAdvice         = "GIVE EXPERT ADVICE"
    static let giveClarification        = "GIVE CLARIFICATION"
    static let withdrawalAdvice         = "WITHDRAWAL ADVICE"
    static let withdrawalClarification  = "WITHDRAWAL CLARIFICATION"
    static let giveAdvice               = "GIVE ADVICE"
    static let withdrawAdvice           = "WITHDRAW ADVICE"
    static let withdrawClarification    = "WITHDRAW CLARIFICATION"
}
