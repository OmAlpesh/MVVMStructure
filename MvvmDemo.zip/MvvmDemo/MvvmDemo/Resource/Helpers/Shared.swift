//
//  Shared.swift
//  NorthGate
//
//  Created by Hardik Kothari on 07/12/16.
//  Copyright © 2016 OSS Cube. All rights reserved.
//

import Foundation
import CoreLocation
import Reachability

class Shared: NSObject, CLLocationManagerDelegate {
    let locationManager: CLLocationManager
    var doubleLat: Double
    var doubleLong: Double
    var strDeviceToken: String
    var strSessionToken: String
    var cartCount: Int
    var reachability: Reachability?
    var isReachable: Bool?
    
    
    //Mark: - Init
    fileprivate override init() {
        self.strDeviceToken = "123456"
        self.strSessionToken = ""
        self.doubleLat = 0
        self.doubleLong = 0
        self.cartCount = 0
        self.locationManager = CLLocationManager()
      
        super.init()
        do {
            reachability = Reachability.init()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(self.reachabilityChanged(_:)), name: Notification.Name.reachabilityChanged, object: reachability)
        do {
            try reachability!.startNotifier()
        } catch {
        }
    }
    
    class var sharedInstance: Shared {
        struct Static {
            static var instance: Shared?
            static var token: Int = 0
        }
        if Static.instance == nil {
            Static.instance = Shared()
        }
        return Static.instance!
    }
    
    //Mark: Rechability
    @objc func reachabilityChanged(_ note: Notification) {
        
        if let reachability = note.object as? Reachability, reachability.isReachable {
            isReachable = true
            if reachability.isReachableViaWiFi {
                print("Reachable via WiFi")
            } else {
                print("Reachable via Cellular")
            }
        } else {
            CommonMethods.hideMBProgressHud()
            DispatchQueue.main.async { [unowned self] in
                let alert: UIAlertController = UIAlertController(title: "", message: "Internet Connection Failed", preferredStyle: .alert )
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                let appDelegate = UIApplication.shared.delegate as? AppDelegate
                Constant.appDelegate?.window?.viewController()?.present(alert, animated: true, completion: nil)
            }
            isReachable = false
        }
    }
    
    //Mark: Current Location
    func getCurrentLocation() {
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            self.locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager( _ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if manager.location != nil {
            let locValue: CLLocationCoordinate2D = manager.location!.coordinate
            doubleLat = locValue.latitude
            doubleLong = locValue.longitude
            manager .stopUpdatingLocation()
        }
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "LocationPermission"), object: nil)
    }
}

