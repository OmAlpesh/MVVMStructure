# MVVMDiscussion
MVVM, a quite popular design architecture for building modularised code. This repo contains sample demo apps build in SWIFT 4 and MVVM.
