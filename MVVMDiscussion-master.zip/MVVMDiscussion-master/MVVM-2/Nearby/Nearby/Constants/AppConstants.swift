//
//  WebServiceConstants.swift
//  Nearby
//
//  Created by Abhisek on 04/02/18.
//  Copyright © 2018 Abhisek. All rights reserved.
//

import Foundation

let googleApiKey = "AIzaSyA-oavokG80m6MAR27ztUWFKVGY7JV_dXU"

