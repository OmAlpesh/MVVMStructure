//
//  AddSourceTableViewController.swift
//  Headlines
//
//  Created by alpesh on 17/01/19.
//  Copyright © 2019 alpesh. All rights reserved.
//

import Foundation
import UIKit

class AddSourceTableViewController : UITableViewController {
    
    private var addSourceViewModel :AddSourceViewModel!
    
    @IBOutlet weak var titleTextField :UITextField!
    @IBOutlet weak var descriptionTextView :BindingTextView!
    @IBOutlet weak var remainingCharactersCountLabel :UILabel!
    
    var addSourceClosure :(SourceViewModel,UIViewController) -> () = { _,_ in }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.addSourceViewModel = AddSourceViewModel()

        self.descriptionTextView.bind { count,limit in
         
            self.remainingCharactersCountLabel.text = "\(self.addSourceViewModel.remainingNumberOfAllowedCharacters(numberOfCharactersEntered: count, limit:limit))"
        }.limit(to: Maximum.allowedCharactersForDescription)
    }
    
    @IBAction func close() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func save() {
        
        let sourceViewModel = SourceViewModel(name: self.titleTextField.text!, description: self.descriptionTextView.text)
        
     //   DispatchQueue.main.async {
            self.addSourceClosure(sourceViewModel,self)
     //   }
    }
    
}
