//
//  MainRouter.swift
//  MVVM+R
//
//  Created by Uday on 23/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit

/// Implementation of MainRouting
final class MainRouter {
    // MARK: - Variables
    ///
    private let launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ///
    private let window: UIWindow
    /// Root view controller of the app
    private var rootVC: UIViewController? {
        return window.rootViewController
    }
    
    // MARK: - Services
    
    // MARK: - Life Cycle Methods
    /// Initialize the router with required dependencies
    /// parameter window: The root window of the application
    init(window: UIWindow, launchOptions: [UIApplication.LaunchOptionsKey: Any]?) {
        self.window = window
        self.launchOptions = launchOptions
    }
    
    // MARK: - Navigaiton methods
    
    /// Call to determine and present the root view for this application. Currently that will be either the tabBar or the initial onboarding slideshow.
    func setInitialViewController() {
        guard let vc = UserManagementRouter(router: self).assembleInitialScreen() else { return }
        window.rootViewController = vc
        window.makeKeyAndVisible()
    }
}
