//
//  OnboardingRouter.swift
//  MVVM+R
//
//  Created by Uday on 24/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit

///
class OnboardingRouter {
    // MARK: - Variables
    ///
    weak private var navigationController: UINavigationController?
    
    // MARK: - Life Cycle Method
    ///
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    // MARK: - Assemble Methods
    ///
    func assembleInitialHomeScreen() -> HomeVC? {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "HomeVC") as? HomeVC else {
            fatalError("Unable to get HomeVC.")
        }
        let viewModel = HomeViewModel(router: self)
        viewModel.controller = vc
        vc.viewModel = viewModel
        return vc
    }

    ///
    func assembleCityScreen() -> CityVC? {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "CityVC") as? CityVC else {
            fatalError("Unable to get CityVC.")
        }
        let viewModel = CityViewModel(router: self)
        viewModel.controller = vc
        vc.viewModel = viewModel
        return vc
    }
    
    // MARK: - Navigation methods
    ///
    func navigateToCityScreen() {
        guard let navigationController = self.navigationController else {
            fatalError("Unable to get navigationController.")
        }
        guard let vc = assembleCityScreen() else {
            fatalError("Unable to get CityVC.")
        }
        navigationController.pushViewController(vc, animated: true)
    }
}

