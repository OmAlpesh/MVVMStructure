//
//  HomeVC.swift
//  MVVM+R
//
//  Created by Uday on 24/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

///
class HomeVC: BaseViewController<HomeViewModel> {
    // MARK: - IBOutlets
    ///
    @IBOutlet weak var tableView: UITableView!
    ///
    @IBOutlet weak var selectCityButton: UIBarButtonItem!
    
    // MARK: - Variables
    ///
    var viewModel: HomeViewModel?
    ///
    let disposeBag = DisposeBag() // Bag of disposables to release them when view is being deallocated
    
    // MARK: - Controller Life Cycle
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        setupRxTableView()
        setupRxActions()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Helper Methods
    ///
    func setNewRecords() {
        // Add new elements after few seconds.
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0) {
            self.viewModel?.addNewElements()
        }
    }
    
    ///
    func setupRxTableView() {
        // Setup tableView properties.
        tableView.estimatedRowHeight = UITableView.automaticDimension
        tableView.register(UINib(nibName: "ListCell", bundle: nil), forCellReuseIdentifier: "ListCell")
        
        // Load teableView data.
        viewModel?.homeList
            .asObservable()
            .bind(to: tableView
            .rx
            .items(cellIdentifier: "ListCell", cellType: ListCell.self)) { row, element, cell in
                cell.selectionStyle = .none
                cell.titleLabel.text = element.homeName
                cell.descriptionLabel.text = element.homeDescription
            }.disposed(by: disposeBag)
        
        // Delegate method for tableView.
        tableView
            .rx
            /*.itemSelected*/ // It will return selected index path.
            .modelSelected(HomeListModel.self) // It will return value.
            .subscribe(onNext: { element in
                print(element.homeId ?? 0)
                print(element.homeName ?? "")
            }).disposed(by: disposeBag)
        
        // Load new records.
        setNewRecords()
    }
    
    ///
    func setupRxActions() {
        // login button action.
        selectCityButton
            .rx
            .tap
            .throttle(RxTimeInterval.microseconds(Int(0.5)), latest: true, scheduler: MainScheduler.instance)
            .subscribe(onNext: {
                print("tapped")
                self.viewModel?.navigateToCityScreen()
            }).disposed(by: disposeBag)
    }
}
