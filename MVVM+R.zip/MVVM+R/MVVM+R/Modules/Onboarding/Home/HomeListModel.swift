//
//  HomeListModel.swift
//  MVVM+R
//
//  Created by Uday on 25/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit
import SwiftyJSON

class HomeListModel: NSObject {
    var homeName: String?
    var homeDescription: String?
    var homeId: Int?
}

extension HomeListModel {
    convenience init(_ data: JSON) {
        self.init()
        homeName = data["homeName"].stringValue
        homeDescription = data["homeDescription"].stringValue
        homeId = data["homeId"].intValue
    }
}
