//
//  CityVC.swift
//  MVVM+R
//
//  Created by Uday on 23/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

///
class CityVC: BaseViewController<CityViewModel> {
    // MARK: - IBOutlet
    ///
    @IBOutlet weak var tableView: UITableView!
    ///
    @IBOutlet weak var searchBar: UISearchBar!
    
    // MARK: - Variables
    ///
    var viewModel: CityViewModel?
    ///
    var shownCities: BehaviorRelay<[CityModel]> = BehaviorRelay<[CityModel]>(value: [])
    ///
    let disposeBag = DisposeBag() // Bag of disposables to release them when view is being deallocated
    
    // MARK: - Controller Lifecycle Methods
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        apiCall()
        setupSearchBar()
        setupTableView()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Helper Methods
    ///
    func setupSearchBar() {
        searchBar
            .rx.text // Observable property thanks to RxCocoa
            .orEmpty // Make it non-optional
            .debounce(RxTimeInterval.milliseconds(Int(0.5)), scheduler: MainScheduler.instance) // Wait 0.5 for changes.
            .distinctUntilChanged() // If they didn't occur, check if the new value is the same as old.
            /*.filter { !$0.isEmpty }*/ // If the new value is really new, filter for non-empty query.
            .subscribe(onNext: { [unowned self] query in // Here we subscribe to every new value, that is not empty (thanks to filter above).
                guard let allCities = self.viewModel?.allCities.value else {
                    return
                }
                self.shownCities.accept(allCities.filter { ($0.cityName ?? "").hasPrefix(query) })
            }).disposed(by: disposeBag)
    }
    
    ///
    func setupTableView() {
        shownCities.asObservable().bind(to: tableView
            .rx
            .items(cellIdentifier: "Cell")) { row, element, cell in
                cell.selectionStyle = .none
                cell.textLabel?.text = element.cityName
            }.disposed(by: disposeBag)
        
        tableView
            .rx
            /*.itemSelected*/ // It will return selected index path.
            .modelSelected(CityModel.self) // It will return value.
            .subscribe(onNext: { element in
                print(element)
            }).disposed(by: disposeBag)
    }
    
    ///
    func apiCall() {
        viewModel?.getCityList().subscribe(onNext: { element in
            print(element)
        }, onError: { error in
            print(error.localizedDescription)
        }, onCompleted: {
            print("onCompleted")
        }, onDisposed: {
            print("onDisposed")
        }).disposed(by: disposeBag)
    }
}
