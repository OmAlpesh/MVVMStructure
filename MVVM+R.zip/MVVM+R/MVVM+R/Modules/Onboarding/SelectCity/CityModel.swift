//
//  CityModel.swift
//  MVVM+R
//
//  Created by Uday on 25/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit
import SwiftyJSON

class CityModel: NSObject {
    var cityName: String?
}

extension CityModel {
    convenience init(_ data: JSON) {
        self.init()
        cityName = data["cityName"].stringValue
    }
}
