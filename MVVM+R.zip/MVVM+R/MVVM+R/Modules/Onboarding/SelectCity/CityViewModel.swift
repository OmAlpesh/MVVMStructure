//
//  CityViewModel.swift
//  MVVM+R
//
//  Created by Uday on 23/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

///
class CityViewModel: Interacting {
    // MARK: - Variables
    ///
    private let router: OnboardingRouter
    ///
    weak var controller: CityVC?
    ///
    let allCities: BehaviorRelay<[CityModel]> = BehaviorRelay<[CityModel]>(value: [])
    
    // MARK: - Init Methods
    ///
    init(router: OnboardingRouter) {
        self.router = router
    }
    
    ///
    func getCityList() -> Observable<String> {
        return Observable<String>.create({ (observer) -> Disposable in
            
            guard self.allCities.value.count == 0 else {
                return Disposables.create(with: {
                    //Cancel the connection if disposed
                    observer.onCompleted()
                })
            }
            
            observer.onNext("Data Append Successfully")
            
            self.allCities.accept([CityModel.init(["cityName": "New York"]), CityModel.init(["cityName": "London"]), CityModel.init(["cityName": "Oslo"]), CityModel.init(["cityName": "Warsaw"]), CityModel.init(["cityName": "Berlin"]), CityModel.init(["cityName": "Praga"])])

            return Disposables.create(with: {
                //Cancel the connection if disposed
                observer.onCompleted()
            })
        })
    }
}
