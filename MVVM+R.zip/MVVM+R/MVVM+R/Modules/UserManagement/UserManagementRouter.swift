//
//  UserManagementRouter.swift
//  MVVM+R
//
//  Created by Uday on 23/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit

///
class UserManagementRouter {
    // MARK: - Variables
    ///
    weak private var navigationController: UINavigationController?
    ///
    weak var mainRouter: MainRouter?
    
    // MARK: - Life Cycle Method
    ///
    init(router: MainRouter) {
        mainRouter = router
    }
    
    // MARK: - Assemble Methods
    ///
    func assembleInitialScreen() -> UINavigationController? {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let navigationController = storyboard.instantiateInitialViewController() as? UINavigationController else {
            fatalError("Unable to get navigationController.")
        }

        self.navigationController = navigationController
        self.navigationController = storyboard.instantiateInitialViewController() as? UINavigationController
        let loginVC = assembleLoginScreen()
        self.navigationController?.setViewControllers([loginVC], animated: true)
        return self.navigationController
    }
    
    ///
    func assembleLoginScreen() -> UIViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "LoginVC") as? LoginVC else {
            fatalError("Unable to get LoginVC.")
        }
        let viewModel = LoginViewModel(router: self)
        viewModel.controller = vc
        vc.viewModel = viewModel
        return vc
    }
    
    // MARK: - Navigation methods
    ///
    func navigateToHome() {
        guard let navigationController = self.navigationController else {
            fatalError("Unable to get navigationController.")
        }
        guard let vc = OnboardingRouter.init(navigationController: navigationController).assembleInitialHomeScreen() else {
            fatalError("Unable to get HomeVC.")
        }
        navigationController.pushViewController(vc, animated: true)
    }
}
