//
//  LoginVC.swift
//  MVVM+R
//
//  Created by Uday on 23/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

///
class LoginVC: BaseViewController<LoginViewModel> {
    // MARK: - IBOutlets
    ///
    @IBOutlet weak var emailTextFiled: UITextField!
    ///
    @IBOutlet weak var passwordTextFiled: UITextField!
    ///
    @IBOutlet weak var loginButton: UIButton!
    
    // MARK: - Variables
    ///
    var viewModel: LoginViewModel?
    ///
    let disposeBag = DisposeBag() // Bag of disposables to release them when view is being deallocated
    
    // MARK: - Controller Lifecycle Methods
    ///
    override func viewDidLoad() {
        super.viewDidLoad()
        setupRxValidation()
        setupRxActions()
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Helper Methods
    ///
    func setupRxValidation() {
        // email validation.
        let emailValid = emailTextFiled
            .rx
            .text
            .orEmpty
            .map { self.viewModel?.validate(email: $0) ?? false }
        emailValid.asObservable().skip(1).subscribe(onNext: { isValid in
            print(isValid)
        }).disposed(by: disposeBag)
        
        // password validation.
        let passwordValid = passwordTextFiled
            .rx
            .text
            .orEmpty
            .map { $0.count > 0 && $0.count <= 10 }
        passwordValid.asObservable().skip(1).subscribe(onNext: { isValid in
            print(isValid)
        }).disposed(by: disposeBag)
        
        // validation on login button.
        let everythingValid = Observable.combineLatest(emailValid, passwordValid) {
                $0 && $1 //All must be true
        }
        everythingValid
            .bind(to: loginButton.rx.isEnabled)
            .disposed(by: disposeBag)
    }
    
    ///
    func setupRxActions() {
        // login button action.
        loginButton
            .rx
            .tap
            .throttle(RxTimeInterval.microseconds(Int(0.5)), latest: true, scheduler: MainScheduler.instance)
            .subscribe(onNext: {
                print("tapped")
                self.viewModel?.navigateToHome()
            }).disposed(by: disposeBag)
    }
}
