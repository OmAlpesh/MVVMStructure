//
//  LoginViewModel.swift
//  MVVM+R
//
//  Created by Uday on 23/07/19.
//  Copyright © 2019 Uday. All rights reserved.
//

/**
 This module exists as an example that can be reused as views/screens/modules are
 added to the app.
 
 MVC is a view layer pattern and does not handle the services, routing,
 dependency injection, and other responsibilities required for a full application.
 
 The Interactor allows the VC to interact with services and navigation without
 those services or routing components being exposed to the VC. This means a more
 clear definition of each class's responsibility, less surface area for defects,
 easier testing, and fewer lines of duplicated code.
 
 The Interactors implement a base Interacting protocol. This allows us to do a bit
 of default wiring between the ViewController (via a BaseViewController<T: Interacting> protocol)
 and Interactor (via Interacting protocol) and have default implementations for
 the ViewController's lifecycle events that may need to bubble up to the Interactor.
 Those protocols are defined in the /Common/BaseContracts folder.
 
 Because there are empty default implementations of the Interacting protocol's
 viewDidLoad, viewWillAppear, and viewWillDisappear methods, we don't need to implement
 them here unless we have functionality that relies on those methods. We often will.
 
 In this example, we have a single dependency: StorageService
 */

import UIKit
import RxSwift
import RxCocoa

///
class LoginViewModel: Interacting {
    // MARK: - Variables
    ///
    private let router: UserManagementRouter?
    ///
    weak var controller: LoginVC?
    
    // MARK: - Init Methods
    ///
    init(router: UserManagementRouter) {
        self.router = router
    }
    
    ///
    func validate(email: String) -> Bool {
        if email.isEmpty {
            return false
        }
        let emailRegEx = "[.0-9a-zA-Z_-]+@[0-9a-zA-Z.-]+\\.[a-zA-Z]{2,20}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        if !emailTest.evaluate(with: email) {
            return false
        }
        return true
    }
    
    // MARK: - Navigation methods
    ///
    func navigateToHome() {
        router?.navigateToHome()
    }
}
